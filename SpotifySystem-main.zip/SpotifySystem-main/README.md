# SpotifySystem

# FR
- Script permettant d'écouter de la musique depuis un menu, sur FiveM.
- Le menu s'ouvre avec la commande /spotify
- Simple d'utilisation
- Optimisation 0.00 ms
- Lib : RageUI et https://github.com/Xogy/xsound
- Pour tout support AigleIsBack#7053 & Yatox#3203

# EN
- Script allowing to listen to music from a menu, on FiveM.
- You can open this menu with command /spotify
- Easily utilisation
- Optimization 0.00 ms
- Lib: RageUI and https://github.com/Xogy/xsound
- For any question AigleIsBack#7053 & Yatox#3203

# Preview
- https://streamable.com/j7nl0o

# Contributor

- [Yatox](https://github.com/Yatox18)
